<div id="footer">
   <?php 
      echo "rpm2php-" . trim(file_get_contents("./version")) . " &copy; 2008-" . date('Y') . " - "; 
   ?> 
   <a href="http://www.rutgers.edu">Rutgers, The State University of New Jersey</a>
   - Contact us (<a href="mailto:oss@oss.rutgers.edu">oss@oss.rutgers.edu</a>) 
   - This site is <a href="http://validator.w3.org/check?uri=referer">XHTML 1.0 valid</a>
</div> 
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-9330916-1");
pageTracker._trackPageview();
} catch(err) {}</script>
	</body>
</html>
