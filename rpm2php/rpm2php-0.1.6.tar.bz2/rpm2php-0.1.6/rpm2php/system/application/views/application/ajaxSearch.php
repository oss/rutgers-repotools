<script type="text/javascript">
	var names = [
<?= 

$search_results; 
//$output = "";
//foreach ($search_results as $function_info) {
//	$output .= $function_info->Name;
//}
//echo $output;
?>

];